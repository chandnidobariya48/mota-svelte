<script>
	import "../assets/css/materialdesignicons.min.css";
	// import "../assets/scss/themes.scss";
	import "../assets/css/style.css"
	import { Styles } from '@sveltestrap/sveltestrap';
</script>
<Styles />
<slot />